﻿#include <iostream>
#include <Windows.h>
#include <bit>


using namespace std;

#pragma pack(push, 1)

typedef struct {
	BYTE Siganture[8];
	GUID CLSID;
	WORD minorVersion;
	WORD majorVersion;
	WORD byteOrder;
	WORD sectorShift;
	WORD miniSectorShift;
	BYTE reserved[6];
	DWORD numOfDirSectors;
	DWORD numOfFATSectors;
	DWORD firstDirSecLoc;
	DWORD TSN;
	DWORD miniStreamCUSize;
	DWORD firstMiniFATSecLoc;
	DWORD numOfMiniFATSectors;
	DWORD firstDIFATSecLoc;
	DWORD numOfDIFATSectors;
	DWORD DIFAT[109];
} CFHeader;

typedef struct {
	WCHAR dirName[32];
	WORD nameLength;
	BYTE objType;
	BYTE colorFlag;
	DWORD leftSibID;
	DWORD rightSibID;
	DWORD childID;
	GUID CLSID;
	DWORD stateBits;
	ULONGLONG creationTime;
	ULONGLONG modifiedTime;
	DWORD startingSecLoc;
	ULONGLONG streamSize;
} DirectoryEntry;

typedef struct {
	WORD vers;
	WORD dt;
	WORD rupBuild;
	WORD rupYear;
	BYTE trash[8];
} BOF;

typedef struct {
	BYTE fShowAutoBreaks : 1;
	BYTE reserved1 : 3;
	BYTE fDialog : 1;
	BYTE fApplyStyles : 1;
	BYTE fRowSumsBelow : 1;
	BYTE fColSumsRight : 1;
	BYTE fFitToPage : 1;
	BYTE reserved2 : 1;
	BYTE unused : 2;
	BYTE fSyncHoriz : 1;
	BYTE fSyncVert : 1;
	BYTE fAltExprEval : 1;
	BYTE fAltFormulaEntry : 1;
} WsBool;

#pragma pack(pop)

WORD reverse_word(WORD in) {
	WORD b2 = in & 0xFF;
	WORD b1 = (in & 0xFF00) >> 8;
	WORD res = (b2 << 8) | b1;
	return res;
}

DWORD reverse_dword(DWORD in) {
	DWORD b4 = in & 0xFF;
	DWORD b3 = (in & 0xFF00) >> 8;
	DWORD b2 = (in & 0xFF0000) >> 16;
	DWORD b1 = (in & 0xFF000000) >> 24;
	DWORD res = (b4 << 24) | (b3 << 16) | (b2 << 8) | b1;
	return res;
}

bool isEqualArr(BYTE* arr1, BYTE* arr2, DWORD size) {
	bool f = true;
	for (int i = 0; i < size; i++) {
		if (arr1[i] != arr2[i]) {
			f = false; 
			break;
		}
	}
	return f;
}

int main() {

	setlocale(LC_ALL, "Russian");

	HANDLE fileHandle = CreateFile(L"2003.xls", GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (fileHandle == INVALID_HANDLE_VALUE) {
		cout << "Ошибка открытия файла!" << endl;
		CloseHandle(fileHandle);
		return 1;
	}
	DWORD fileSize = GetFileSize(fileHandle, NULL);
	DWORD bytesRead;
	BYTE* buf = new BYTE[fileSize];
	BOOL readOK = ReadFile(fileHandle, buf, fileSize, &bytesRead, NULL);
	if (!readOK) {
		cout << "Ошибка чтения файла!" << endl;
		CloseHandle(fileHandle);
		return -1;
	}
	BYTE trueHeaderSig[] = { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 };
	CFHeader cfh;
	DWORD fileOffset = 0;
	memcpy(&cfh, &buf[fileOffset], sizeof(cfh)); 
	if (!isEqualArr(trueHeaderSig, cfh.Siganture, 8)) {
		wcout << L"Файл не является Compound File!\n";
		return 1;
	}
	fileOffset += sizeof(cfh);

	fileOffset += cfh.firstDirSecLoc * pow(2, cfh.sectorShift);
	DirectoryEntry de;

	while (true) {
		memcpy(&de, &buf[fileOffset], sizeof(DirectoryEntry));
		if (wstring(de.dirName) == L"Workbook") {
			wcout << L"Workbook stream found!" << endl;
			fileOffset = sizeof(CFHeader) + de.startingSecLoc * pow(2, cfh.sectorShift);
			break;
		}
		fileOffset += 128;
	}
	DWORD fatsecloc = cfh.DIFAT[0];
	DWORD secSize = pow(2, cfh.sectorShift);
	DWORD* FAT = new DWORD[secSize / 4];
	memcpy(FAT, &buf[secSize * (fatsecloc + 1)], secSize);
	cout << FAT[de.startingSecLoc] << endl;
	BOF StreamBOF;
	DWORD wbOffset = fileOffset;
	while (1) {
		memcpy(&StreamBOF, &buf[fileOffset], 16);
		if (StreamBOF.dt == 0x5 and StreamBOF.trash[4] == 6 and (StreamBOF.rupYear == 0x7cc or StreamBOF.rupYear == 0x7cd) and StreamBOF.vers == 0x600) {
			cout << "Globals Substream found! Offset difference to workbook stream BOF: " << (fileOffset - wbOffset) << endl;
			fileOffset += 16;
			break;
		}
		else {
			fileOffset += 1;
		}
	}
	CloseHandle(fileHandle);
	delete[] buf;
	delete[] FAT;
	return 0;
}